to use:

```
./comparable.py file1.txt file2.txt
```

Defaults to using base.txt and compare.txt

Run on Python 2.7.6 and Python 3.4.3
