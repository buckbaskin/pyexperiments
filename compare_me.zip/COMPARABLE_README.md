to use:

```
./comparable.py file1.txt file2.txt
```

Defaults to using base.txt and compare.txt
